package robostar.robocert.textual.tests.util;

import com.google.inject.AbstractModule;

public class RoboCertCustomModule extends AbstractModule {
	@Override
	protected void configure() {
	}
}
