# RoboCert standard library

This directory contains CSP-M files that are copied into the output of the
RoboCert generator, and referenced by the generated files.